const { ok } = require('../utils/response');
const { uploadMedia } = require('../services/mediaStorageService');

function upload(req, res) {
  return ok(res, uploadMedia(req.body));
}

module.exports = { upload };
