const { ok } = require('../utils/response');
const { createReport } = require('../services/moderationService');

function report(req, res) {
  return ok(res, createReport(req.body));
}

module.exports = { report };
