const { ok, fail } = require('../utils/response');
const { walletSummary, createP2PTransfer } = require('../services/paymentService');

function wallet(req, res) {
  return ok(res, walletSummary(req.user.id));
}

function sendP2P(req, res) {
  if (!req.body.recipientUserId || !req.body.amount) {
    return fail(res, 'recipientUserId and amount are required');
  }
  return ok(res, createP2PTransfer(req.body));
}

module.exports = { wallet, sendP2P };
