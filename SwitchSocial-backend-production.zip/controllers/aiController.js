const { ok } = require('../utils/response');
const { scanMedia } = require('../services/aiDetectionService');

function scan(req, res) {
  return ok(res, scanMedia(req.body));
}

module.exports = { scan };
