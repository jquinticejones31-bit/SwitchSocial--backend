function check(req, res) {
  res.json({ ok: true, service: 'switchsocial-backend', status: 'healthy' });
}

module.exports = { check };
