const { ok } = require('../utils/response');
const { getAlgorithmBuilder } = require('../services/algorithmService');

function builder(req, res) {
  return ok(res, getAlgorithmBuilder());
}

module.exports = { builder };
