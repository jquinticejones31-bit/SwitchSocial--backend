const { ok } = require('../utils/response');
const { getTalkyardCommunities } = require('../services/talkyardService');

function communities(req, res) {
  return ok(res, getTalkyardCommunities());
}

module.exports = { communities };
