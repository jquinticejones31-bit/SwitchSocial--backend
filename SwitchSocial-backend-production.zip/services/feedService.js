function getLinkupsFeed() {
  return {
    network: 'Linkups',
    items: [
      { id: 'post_1', type: 'post', text: 'Welcome to Linkups feed' },
      { id: 'post_2', type: 'video', text: 'Short video post example' }
    ]
  };
}

module.exports = { getLinkupsFeed };
