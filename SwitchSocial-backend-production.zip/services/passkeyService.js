function beginRegistration(email) {
  return {
    email,
    method: 'passkey_only',
    requiresEmailVerification: true,
    challenge: 'replace-with-real-passkey-challenge'
  };
}

function beginAuthentication(email) {
  return {
    email,
    method: 'passkey_only',
    challenge: 'replace-with-real-auth-challenge'
  };
}

module.exports = { beginRegistration, beginAuthentication };
