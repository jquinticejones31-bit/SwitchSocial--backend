function createReport(body = {}) {
  return {
    contentId: body.contentId,
    reason: body.reason || 'unspecified',
    status: 'open',
    appealsSupported: true
  };
}

module.exports = { createReport };
