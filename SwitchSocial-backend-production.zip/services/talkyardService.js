function getTalkyardCommunities() {
  return {
    network: 'Talkyard',
    communities: [
      { id: 'community_1', name: 'General', nsfw: false },
      { id: 'community_2', name: 'Creators', nsfw: true }
    ],
    nestedComments: true,
    upvotesDownvotes: true
  };
}

module.exports = { getTalkyardCommunities };
