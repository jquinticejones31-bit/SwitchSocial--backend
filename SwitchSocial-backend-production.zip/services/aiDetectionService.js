function scanMedia(payload = {}) {
  return {
    aiGeneratedText: !!payload.aiGeneratedText,
    aiGeneratedImage: !!payload.aiGeneratedImage,
    aiGeneratedVideo: !!payload.aiGeneratedVideo,
    photoshopManipulationDetected: !!payload.photoshopManipulationDetected,
    action: payload.deceptiveOrHarmful ? 'remove' : 'label_and_reduce_distribution'
  };
}

module.exports = { scanMedia };
