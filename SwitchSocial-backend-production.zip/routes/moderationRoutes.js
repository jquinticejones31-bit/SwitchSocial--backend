const router = require('express').Router();
const controller = require('../controllers/moderationController');
const authenticate = require('../middleware/authenticate');

router.post('/report', authenticate, controller.report);

module.exports = router;
