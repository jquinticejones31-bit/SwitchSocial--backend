console.log('Seed runner scaffold');
console.log('Add demo users, posts, stories, and communities here.');
