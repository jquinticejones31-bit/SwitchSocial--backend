CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  username TEXT UNIQUE,
  profile_type TEXT NOT NULL DEFAULT 'regular',
  followers INTEGER NOT NULL DEFAULT 0,
  passkey_enabled BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS posts (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL,
  network TEXT NOT NULL,
  content TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS stories (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL,
  media_type TEXT NOT NULL,
  ai_labeled BOOLEAN NOT NULL DEFAULT FALSE,
  permanent BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS communities (
  id UUID PRIMARY KEY,
  name TEXT NOT NULL,
  nsfw BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS payments (
  id UUID PRIMARY KEY,
  sender_user_id UUID,
  recipient_user_id UUID,
  amount_cents INTEGER NOT NULL,
  currency TEXT NOT NULL DEFAULT 'USD',
  status TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS moderation_reports (
  id UUID PRIMARY KEY,
  content_id TEXT NOT NULL,
  reason TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open'
);

CREATE TABLE IF NOT EXISTS algorithms (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL,
  config_json JSONB NOT NULL
);

CREATE TABLE IF NOT EXISTS media_assets (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL,
  storage_provider TEXT NOT NULL,
  storage_key TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);
