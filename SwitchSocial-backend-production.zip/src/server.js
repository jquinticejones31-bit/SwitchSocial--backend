const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
require('dotenv').config();

const { env } = require('./config/env');
const authRoutes = require('./routes/authRoutes');
const feedRoutes = require('./routes/feedRoutes');
const communitiesRoutes = require('./routes/communityRoutes');
const storiesRoutes = require('./routes/storyRoutes');
const paymentRoutes = require('./routes/paymentRoutes');
const moderationRoutes = require('./routes/moderationRoutes');
const algorithmRoutes = require('./routes/algorithmRoutes');
const playbackRoutes = require('./routes/playbackRoutes');
const userRoutes = require('./routes/userRoutes');
const notificationRoutes = require('./routes/notificationRoutes');
const messageRoutes = require('./routes/messageRoutes');
const healthRoutes = require('./routes/healthRoutes');
const errorHandler = require('./middleware/errorHandler');

const app = express();

app.use(helmet());
app.use(cors({ origin: env.CLIENT_URL || '*' }));
app.use(express.json({ limit: '15mb' }));
app.use(morgan('dev'));

app.use('/health', healthRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/feed', feedRoutes);
app.use('/api/communities', communitiesRoutes);
app.use('/api/stories', storiesRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/moderation', moderationRoutes);
app.use('/api/algorithms', algorithmRoutes);
app.use('/api/playback', playbackRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/messages', messageRoutes);

app.get('/', (req, res) => {
  res.json({
    ok: true,
    service: 'SwitchSocial Backend',
    deploymentTargets: ['Docker', 'Google Cloud Run', 'Google Cloud Build', 'GitHub']
  });
});

app.use(errorHandler);

app.listen(env.PORT, () => {
  console.log(`SwitchSocial backend running on port ${env.PORT}`);
});
