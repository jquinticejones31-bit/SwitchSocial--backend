class Post {
  constructor(data = {}) {
    Object.assign(this, data);
  }
}
module.exports = Post;
