class ModerationCase {
  constructor(data = {}) {
    Object.assign(this, data);
  }
}
module.exports = ModerationCase;
