class Payment {
  constructor(data = {}) {
    Object.assign(this, data);
  }
}
module.exports = Payment;
