class Profile {
  constructor(data = {}) {
    this.id = data.id;
    this.userId = data.userId;
    this.bio = data.bio || '';
    this.friendsEnabled = !!data.friendsEnabled;
  }
}
module.exports = Profile;
