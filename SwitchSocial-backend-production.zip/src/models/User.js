class User {
  constructor(data = {}) {
    this.id = data.id;
    this.email = data.email;
    this.username = data.username;
    this.profileType = data.profileType || 'regular';
    this.followers = data.followers || 0;
    this.badge = data.badge || 'regular';
    this.parentalConsentVerified = !!data.parentalConsentVerified;
  }
}
module.exports = User;
