class Story {
  constructor(data = {}) {
    Object.assign(this, data);
  }
}
module.exports = Story;
