function canBoost({ profileType, followers = 0, lgbtqOptIn = false, famous = false }) {
  if (profileType === 'regular' || profileType === 'adult_creator') return true;
  if (profileType === 'business' && followers < 100000) return true;
  if (lgbtqOptIn && !famous) return true;
  return false;
}

module.exports = { canBoost };
