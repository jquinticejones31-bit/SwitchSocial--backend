function walletSummary(userId) {
  return {
    userId,
    balance: 0,
    currency: 'USD',
    provider: 'Stripe',
    p2pEnabled: true,
    requiresKycAml: true
  };
}

function createP2PPayment(body) {
  return {
    type: 'p2p',
    amount: body.amount,
    currency: body.currency || 'USD',
    recipientUserId: body.recipientUserId,
    status: 'pending_compliance_review'
  };
}

module.exports = { walletSummary, createP2PPayment };
