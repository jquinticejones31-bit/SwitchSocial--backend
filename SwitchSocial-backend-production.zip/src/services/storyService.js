function listStories() {
  return [
    { id: 'story_1', type: 'image', permanent: true, aiLabeled: false },
    { id: 'story_2', type: 'video', permanent: true, aiLabeled: true }
  ];
}

module.exports = { listStories };
