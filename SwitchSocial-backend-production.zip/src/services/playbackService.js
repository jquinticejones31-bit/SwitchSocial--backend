const { env } = require('../config/env');

function getPlaybackSession() {
  return {
    playbackUrl: 'https://replace-with-real-playback-url.invalid/stream.m3u8',
    apikey: env.PLAYBACK_API_KEY || 'replace_me',
    rules: [
      'Use returned playbackUrl only',
      'No hardcoding',
      'Stop playback on logout',
      'Handle expired URLs'
    ]
  };
}

module.exports = { getPlaybackSession };
