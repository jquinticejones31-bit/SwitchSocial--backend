const Stripe = require('stripe');
const { env } = require('../config/env');

function getStripeClient() {
  if (!env.STRIPE_SECRET_KEY) return null;
  return new Stripe(env.STRIPE_SECRET_KEY);
}

module.exports = { getStripeClient };
