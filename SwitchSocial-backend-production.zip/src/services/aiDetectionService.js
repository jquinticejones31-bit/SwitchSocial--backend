function inspectContent(payload = {}) {
  return {
    aiGeneratedText: !!payload.aiGeneratedText,
    aiGeneratedImage: !!payload.aiGeneratedImage,
    aiGeneratedVideo: !!payload.aiGeneratedVideo,
    aiGeneratedStory: !!payload.aiGeneratedStory,
    photoshopManipulationDetected: !!payload.photoshopManipulationDetected,
    enforcement: payload.deceptiveOrHarmful ? 'remove' : 'label_and_reduce_distribution'
  };
}

module.exports = { inspectContent };
