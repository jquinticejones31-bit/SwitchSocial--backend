function builderDefinition() {
  return {
    controls: ['ranking_logic', 'stories_priority', 'badges', 'nsfw', 'ads'],
    defaultAlgorithmAlwaysAvailable: true,
    safetyOverridesApply: true,
    transparencyLabel: 'Why am I seeing this?'
  };
}

module.exports = { builderDefinition };
