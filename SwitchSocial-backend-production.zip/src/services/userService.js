const { resolveBadge } = require('./badgeService');
const { canBoost } = require('./boostService');

function getUserProfile(id) {
  const profile = {
    id,
    username: 'switchsocial_user',
    profileType: 'business',
    followers: 1200,
    friendsEnabled: true,
    incorporated: false
  };

  return {
    ...profile,
    badge: resolveBadge(profile),
    boosted: canBoost(profile)
  };
}

module.exports = { getUserProfile };
