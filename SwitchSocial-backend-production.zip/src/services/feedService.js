function getHomeFeed() {
  return [
    { id: 'post_1', network: 'Linkups', type: 'post', text: 'Welcome to Linkups' },
    { id: 'post_2', network: 'Talkyard', type: 'discussion', text: 'Welcome to Talkyard' }
  ];
}

module.exports = { getHomeFeed };
