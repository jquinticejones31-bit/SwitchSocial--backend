function resolveBadge({ profileType, followers = 0, incorporated = false }) {
  if (['government', 'official', 'bank'].includes(profileType)) return 'white';
  if (profileType === 'celebrity') return 'green';
  if (profileType === 'business' && (incorporated || followers >= 100000)) return 'purple';
  if (profileType === 'business') return 'blue';
  if (['school', 'university', 'military'].includes(profileType)) return 'navy';
  if (profileType === 'adult_creator') return 'red';
  if (profileType === 'platform_creator') return 'black';
  return 'regular';
}

module.exports = { resolveBadge };
