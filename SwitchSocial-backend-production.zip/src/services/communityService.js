function listCommunities() {
  return [
    { id: 'community_1', name: 'General', nsfw: false },
    { id: 'community_2', name: 'Creators', nsfw: true }
  ];
}

module.exports = { listCommunities };
