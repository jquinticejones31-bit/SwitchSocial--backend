function listInbox() {
  return {
    chats: [{ id: 'chat_1', title: 'Welcome chat' }],
    notificationsToggleStyle: 'reddit_like'
  };
}

module.exports = { listInbox };
