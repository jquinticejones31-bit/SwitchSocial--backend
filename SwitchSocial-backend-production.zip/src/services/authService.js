const { newId } = require('../utils/id');

function beginSignup(email, teenAccount = false) {
  return {
    userId: newId('user'),
    email,
    method: 'passkey_only',
    verifiedEmailRequired: true,
    parentalConsentRequired: teenAccount
  };
}

function beginLogin() {
  return {
    method: 'passkey_only',
    sharedDevicesShouldUseSessionOnly: true
  };
}

module.exports = { beginSignup, beginLogin };
