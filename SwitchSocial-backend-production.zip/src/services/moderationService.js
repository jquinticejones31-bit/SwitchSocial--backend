function createCase(reason, contentId) {
  return {
    status: 'open',
    reason,
    contentId,
    appealsSupported: true
  };
}

module.exports = { createCase };
