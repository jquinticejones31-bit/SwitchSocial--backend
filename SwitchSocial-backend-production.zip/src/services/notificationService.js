function listNotifications() {
  return [
    { id: 'notif_1', type: 'like', text: 'Someone liked your post' },
    { id: 'notif_2', type: 'payment', text: 'You received a payment' }
  ];
}

module.exports = { listNotifications };
