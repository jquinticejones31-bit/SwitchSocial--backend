module.exports = function validateBody(requiredFields = []) {
  return function(req, res, next) {
    const missing = requiredFields.filter((field) => req.body[field] === undefined);
    if (missing.length) {
      return res.status(400).json({ ok: false, error: `Missing fields: ${missing.join(', ')}` });
    }
    next();
  };
};
