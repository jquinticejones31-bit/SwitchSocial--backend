module.exports = function requireVerifiedEmail(req, res, next) {
  if (!req.user || !req.user.verifiedEmail) {
    return res.status(403).json({ ok: false, error: 'Verified email required' });
  }
  next();
};
