function ok(res, data) {
  return res.json({ ok: true, data });
}

function created(res, data) {
  return res.status(201).json({ ok: true, data });
}

function fail(res, message, code = 400) {
  return res.status(code).json({ ok: false, error: message });
}

module.exports = { ok, created, fail };
