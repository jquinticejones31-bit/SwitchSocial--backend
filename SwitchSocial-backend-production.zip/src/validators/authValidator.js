function validateSignup(body = {}) {
  return !!body.email;
}

module.exports = { validateSignup };
