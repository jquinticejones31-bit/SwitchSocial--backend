function validateP2P(body = {}) {
  return !!body.recipientUserId && !!body.amount;
}

module.exports = { validateP2P };
