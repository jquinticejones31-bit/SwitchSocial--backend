const fs = require('fs');
const path = require('path');

console.log('Migration runner scaffold');
console.log('Apply SQL files in:', path.join(__dirname));
console.log(fs.readdirSync(__dirname).filter((f) => f.endsWith('.sql')));
