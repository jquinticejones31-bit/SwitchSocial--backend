const seed = require('./devSeed');

console.log('Seed runner scaffold');
console.log(seed);
