module.exports = {
  users: [
    { email: 'demo@switchsocial.app', username: 'demo_user' }
  ]
};
