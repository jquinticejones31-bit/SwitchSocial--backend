const { Pool } = require('pg');
const { env } = require('./env');

let pool = null;

function getPool() {
  if (!pool) {
    pool = new Pool({
      connectionString: env.DATABASE_URL || undefined
    });
  }
  return pool;
}

module.exports = { getPool };
