module.exports = {
  prohibited: [
    'bullying',
    'harassment',
    'threats',
    'hate_speech',
    'doxxing',
    'impersonation',
    'brigading',
    'sexual_exploitation',
    'minor_exploitation',
    'repeated_unwanted_contact'
  ],
  messagingRules: {
    anyoneCanMessageAnyone: true,
    globalChatBlocking: false,
    individualBlocking: true
  }
};
