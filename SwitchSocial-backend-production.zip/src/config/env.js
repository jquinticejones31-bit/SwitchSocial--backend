require('dotenv').config();

const env = {
  PORT: process.env.PORT || 8080,
  NODE_ENV: process.env.NODE_ENV || 'development',
  CLIENT_URL: process.env.CLIENT_URL || '*',
  DATABASE_URL: process.env.DATABASE_URL || '',
  JWT_SECRET: process.env.JWT_SECRET || 'change_me',
  STRIPE_SECRET_KEY: process.env.STRIPE_SECRET_KEY || '',
  STRIPE_WEBHOOK_SECRET: process.env.STRIPE_WEBHOOK_SECRET || '',
  PLAYBACK_API_BASE: process.env.PLAYBACK_API_BASE || 'https://api.yourdomain.com',
  PLAYBACK_API_KEY: process.env.PLAYBACK_API_KEY || ''
};

module.exports = { env };
