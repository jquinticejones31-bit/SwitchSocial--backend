module.exports = {
  badges: {
    white: 'Governments, officials, banks',
    green: 'Celebrities',
    blue: 'Small businesses',
    purple: 'Incorporated / large businesses',
    navy: 'Schools, universities, military',
    red: 'Adult / subscription creators',
    black: 'Twitch, YouTube, Meta, TikTok creators',
    rainbow: 'LGBTQ opt-in',
    regular: 'Yellow / Brown / Gold / Rose Gold regular users'
  }
};
