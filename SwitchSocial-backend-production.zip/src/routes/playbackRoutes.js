const router = require('express').Router();
const controller = require('../controllers/playbackController');
const authenticate = require('../middleware/authenticate');

router.get('/', authenticate, controller.session);

module.exports = router;
