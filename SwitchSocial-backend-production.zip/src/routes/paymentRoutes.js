const router = require('express').Router();
const controller = require('../controllers/paymentController');
const authenticate = require('../middleware/authenticate');
const requireVerifiedEmail = require('../middleware/requireVerifiedEmail');

router.get('/wallet', authenticate, requireVerifiedEmail, controller.wallet);
router.post('/p2p/send', authenticate, requireVerifiedEmail, controller.sendP2P);

module.exports = router;
