const router = require('express').Router();
const controller = require('../controllers/feedController');
const authenticate = require('../middleware/authenticate');

router.get('/home', authenticate, controller.home);

module.exports = router;
