const router = require('express').Router();
const controller = require('../controllers/healthController');

router.get('/', controller.check);

module.exports = router;
