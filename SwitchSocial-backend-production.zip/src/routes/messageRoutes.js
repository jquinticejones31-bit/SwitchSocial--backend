const router = require('express').Router();
const controller = require('../controllers/messageController');
const authenticate = require('../middleware/authenticate');

router.get('/inbox', authenticate, controller.inbox);

module.exports = router;
