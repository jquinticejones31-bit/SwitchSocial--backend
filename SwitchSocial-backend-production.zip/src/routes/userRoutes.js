const router = require('express').Router();
const controller = require('../controllers/userController');
const authenticate = require('../middleware/authenticate');

router.get('/:id', authenticate, controller.show);

module.exports = router;
