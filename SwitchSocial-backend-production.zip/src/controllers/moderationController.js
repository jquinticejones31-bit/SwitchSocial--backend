const { ok } = require('../utils/apiResponse');
const { inspectContent } = require('../services/aiDetectionService');
const { createCase } = require('../services/moderationService');

function scan(req, res) {
  const result = inspectContent(req.body);
  return ok(res, {
    scan: result,
    case: createCase('ai_or_media_manipulation_review', req.body.contentId || 'unknown')
  });
}

module.exports = { scan };
