const { ok } = require('../utils/apiResponse');
const { builderDefinition } = require('../services/algorithmService');

function builder(req, res) {
  return ok(res, builderDefinition());
}

module.exports = { builder };
