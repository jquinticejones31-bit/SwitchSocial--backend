const { ok } = require('../utils/apiResponse');
const { getPlaybackSession } = require('../services/playbackService');

function session(req, res) {
  return ok(res, getPlaybackSession());
}

module.exports = { session };
