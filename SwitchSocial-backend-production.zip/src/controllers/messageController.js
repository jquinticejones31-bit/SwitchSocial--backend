const { ok } = require('../utils/apiResponse');
const { listInbox } = require('../services/messageService');

function inbox(req, res) {
  return ok(res, listInbox());
}

module.exports = { inbox };
