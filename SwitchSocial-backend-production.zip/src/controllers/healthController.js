function check(req, res) {
  return res.json({ ok: true, service: 'switchsocial-backend', status: 'healthy' });
}

module.exports = { check };
