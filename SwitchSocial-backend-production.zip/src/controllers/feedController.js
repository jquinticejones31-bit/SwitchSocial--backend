const { ok } = require('../utils/apiResponse');
const { getHomeFeed } = require('../services/feedService');

function home(req, res) {
  return ok(res, {
    feed: getHomeFeed(),
    permanentStoriesEnabled: true
  });
}

module.exports = { home };
