const { ok } = require('../utils/apiResponse');
const { getUserProfile } = require('../services/userService');

function show(req, res) {
  return ok(res, getUserProfile(req.params.id));
}

module.exports = { show };
