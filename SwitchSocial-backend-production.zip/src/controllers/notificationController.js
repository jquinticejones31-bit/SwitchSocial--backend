const { ok } = require('../utils/apiResponse');
const { listNotifications } = require('../services/notificationService');

function index(req, res) {
  return ok(res, listNotifications());
}

module.exports = { index };
