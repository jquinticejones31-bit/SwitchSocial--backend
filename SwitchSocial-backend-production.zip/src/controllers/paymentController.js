const { ok, fail } = require('../utils/apiResponse');
const { walletSummary, createP2PPayment } = require('../services/paymentService');
const { validateP2P } = require('../validators/paymentValidator');

function wallet(req, res) {
  return ok(res, walletSummary(req.user.id));
}

function sendP2P(req, res) {
  if (!validateP2P(req.body)) return fail(res, 'recipientUserId and amount are required');
  return ok(res, createP2PPayment(req.body));
}

module.exports = { wallet, sendP2P };
