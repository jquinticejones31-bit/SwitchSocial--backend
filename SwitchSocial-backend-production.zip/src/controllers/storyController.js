const { ok } = require('../utils/apiResponse');
const { listStories } = require('../services/storyService');

function index(req, res) {
  return ok(res, listStories());
}

module.exports = { index };
