const { ok } = require('../utils/apiResponse');
const { listCommunities } = require('../services/communityService');

function index(req, res) {
  return ok(res, listCommunities());
}

module.exports = { index };
