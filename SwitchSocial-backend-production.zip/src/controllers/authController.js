const { ok, fail } = require('../utils/apiResponse');
const { beginSignup, beginLogin } = require('../services/authService');
const { validateSignup } = require('../validators/authValidator');

function signup(req, res) {
  if (!validateSignup(req.body)) return fail(res, 'Email is required');
  return ok(res, beginSignup(req.body.email, !!req.body.teenAccount));
}

function login(req, res) {
  return ok(res, beginLogin());
}

module.exports = { signup, login };
