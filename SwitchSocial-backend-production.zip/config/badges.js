module.exports = {
  badges: {
    white: 'government_official_bank',
    green: 'celebrity',
    blue: 'small_business',
    purple: 'large_business',
    navy: 'school_university_military',
    red: 'adult_creator',
    black: 'major_platform_creator',
    rainbow: 'lgbtq_opt_in',
    regular: 'regular_user'
  }
};
