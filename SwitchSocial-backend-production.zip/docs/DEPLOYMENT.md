# Deployment

## Docker
docker build -t switchsocial-backend .

## Google Cloud Build
gcloud builds submit --tag gcr.io/YOUR_PROJECT_ID/switchsocial-backend

## Google Cloud Run
gcloud run deploy switchsocial-backend   --image gcr.io/YOUR_PROJECT_ID/switchsocial-backend   --platform managed   --region us-central1   --allow-unauthenticated
