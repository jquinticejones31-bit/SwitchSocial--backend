SwitchSocial advanced backend scaffold.

Included:
- passkey authentication starter
- Linkups feed engine starter
- Talkyard discussion engine starter
- permanent stories starter
- Stripe + P2P payments starter
- AI / Photoshop detection starter
- PostgreSQL schema + migrations starter
- moderation + reporting starter
- user-created algorithm engine starter
- media storage starter
- streaming playback starter
