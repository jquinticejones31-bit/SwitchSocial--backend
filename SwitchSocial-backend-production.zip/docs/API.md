# API Endpoints

- `POST /api/auth/signup`
- `POST /api/auth/login`
- `GET /api/users/:id`
- `GET /api/feed/home`
- `GET /api/communities`
- `GET /api/stories`
- `GET /api/payments/wallet`
- `POST /api/payments/p2p/send`
- `POST /api/moderation/scan`
- `GET /api/algorithms/builder`
- `GET /api/playback`
- `GET /api/notifications`
- `GET /api/messages/inbox`
