class ModerationReport {
  constructor(data = {}) {
    Object.assign(this, data);
  }
}
module.exports = ModerationReport;
