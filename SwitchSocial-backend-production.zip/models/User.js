class User {
  constructor(data = {}) {
    this.id = data.id;
    this.email = data.email;
    this.username = data.username;
    this.profileType = data.profileType || 'regular';
    this.followers = data.followers || 0;
    this.passkeyEnabled = !!data.passkeyEnabled;
  }
}
module.exports = User;
