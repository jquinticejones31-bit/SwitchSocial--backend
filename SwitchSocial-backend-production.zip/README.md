# SwitchSocial Backend

A fuller backend starter repo for SwitchSocial with:

- Docker
- Google Cloud Run
- Google Cloud Build
- GitHub Actions deployment starter
- authentication scaffold
- Linkups feed
- Talkyard communities
- permanent stories
- Stripe + P2P payments scaffold
- AI / Photoshop detection pipeline scaffold
- PostgreSQL schema starter
- moderation system
- algorithm builder starter

## Quick start

```bash
cp .env.example .env
npm install
npm start
```

## Docker

```bash
docker build -t switchsocial-backend .
docker run -p 8080:8080 --env-file .env switchsocial-backend
```

## Google Cloud Build

```bash
gcloud builds submit --tag gcr.io/YOUR_PROJECT_ID/switchsocial-backend
```

## Google Cloud Run

```bash
gcloud run deploy switchsocial-backend   --image gcr.io/YOUR_PROJECT_ID/switchsocial-backend   --platform managed   --region us-central1   --allow-unauthenticated
```

## GitHub push

```bash
git init
git add .
git commit -m "Initial SwitchSocial backend"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

## Notes

This is a production-style scaffold, not a finished live social network. Payment, moderation, passkeys, and AI detection integrations are wired as safe starter code and placeholders.
