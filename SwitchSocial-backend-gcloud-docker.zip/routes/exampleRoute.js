const router = require('express').Router()

router.get('/example',(req,res)=>{
  res.json({message:'example route'})
})

module.exports = router