const express = require('express')
const cors = require('cors')
require('dotenv').config()

const app = express()
app.use(cors())
app.use(express.json())

app.get('/', (req,res)=>{
  res.json({service:"SwitchSocial API"})
})

app.get('/playback',(req,res)=>{
  res.json({
    playbackUrl:"https://example-stream-url",
    apikey:"example-key"
  })
})

const PORT = process.env.PORT || 8080
app.listen(PORT,()=>{
  console.log("API running on port",PORT)
})