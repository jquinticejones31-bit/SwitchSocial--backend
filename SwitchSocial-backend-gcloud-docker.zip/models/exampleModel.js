class ExampleModel {
  constructor(data){
    this.id=data.id
  }
}

module.exports = ExampleModel