module.exports = {
  example: () => {
    return { status: "service working" }
  }
}