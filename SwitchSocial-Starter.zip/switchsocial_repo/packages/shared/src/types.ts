export type ProductTab = 'linkups' | 'talkyard';

export type ProfileType =
  | 'regular'
  | 'small_business'
  | 'large_business'
  | 'celebrity'
  | 'government'
  | 'military'
  | 'school'
  | 'adult_creator'
  | 'creator_platform';

export type BadgeColor =
  | 'white'
  | 'green'
  | 'blue'
  | 'purple'
  | 'navy'
  | 'red'
  | 'black'
  | 'rainbow'
  | 'yellow'
  | 'brown'
  | 'gold'
  | 'rose_gold';

export interface UserProfile {
  id: string;
  handle: string;
  displayName: string;
  type: ProfileType;
  badge?: BadgeColor;
  followers: number;
  friendsEnabled: boolean;
  lgbtqOptIn?: boolean;
  verifiedEmail: boolean;
  teenAccount?: boolean;
  parentConsentVerified?: boolean;
}

export interface AlgorithmSettings {
  rankingLogic: 'latest' | 'engagement' | 'hybrid' | 'following_first';
  prioritizeStories: boolean;
  prioritizeBadges: boolean;
  allowNsfw: boolean;
  allowAds: boolean;
}
