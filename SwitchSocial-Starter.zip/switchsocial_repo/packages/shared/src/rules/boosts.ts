import type { UserProfile } from '../types';

export function isAlwaysBoosted(profile: UserProfile): boolean {
  return profile.type === 'regular' || profile.type === 'adult_creator';
}

export function isConditionallyBoosted(profile: UserProfile): boolean {
  return (
    (profile.type === 'small_business' && profile.followers < 100000) ||
    (!!profile.lgbtqOptIn && profile.type === 'regular')
  );
}

export function isNeverBoosted(profile: UserProfile): boolean {
  return ['government', 'military', 'celebrity', 'large_business'].includes(profile.type);
}
