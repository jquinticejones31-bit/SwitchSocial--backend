import type { BadgeColor, ProfileType, UserProfile } from '../types';

export const BADGE_RULES: Record<BadgeColor, string> = {
  white: 'Governments, officials, banks',
  green: 'Celebrities',
  blue: 'Small businesses',
  purple: 'Incorporated / large businesses',
  navy: 'Schools, universities, military',
  red: 'Adult / subscription creators',
  black: 'Large creators from creator platforms',
  rainbow: 'Opt-in LGBTQ badge',
  yellow: 'Regular user verification option',
  brown: 'Regular user verification option',
  gold: 'Regular user verification option',
  rose_gold: 'Regular user verification option'
};

export function recommendedBadge(profile: UserProfile): BadgeColor | undefined {
  if (profile.type === 'government') return 'white';
  if (profile.type === 'celebrity') return 'green';
  if (profile.type === 'small_business') return profile.followers >= 100000 ? 'purple' : 'blue';
  if (profile.type === 'large_business') return 'purple';
  if (profile.type === 'school' || profile.type === 'military') return 'navy';
  if (profile.type === 'adult_creator') return 'red';
  if (profile.type === 'creator_platform') return 'black';
  return profile.lgbtqOptIn ? 'rainbow' : profile.badge;
}

export function requiresIncorporationDocs(type: ProfileType, followers: number): boolean {
  return type === 'large_business' || (type === 'small_business' && followers >= 100000);
}
