export const PLATFORM_RULES = {
  auth: {
    passwordless: true,
    verifiedEmailRequired: true,
    passkeysOnly: true,
    noSavedCredentialsOnSharedDevices: true,
    multiDevice: true,
    teenParentConsentRequired: true
  },
  stories: {
    expiresAutomatically: false,
    deleteByUserOnly: true,
    aiLabelRequired: true
  },
  messaging: {
    anyoneCanMessageAnyone: true,
    globalChatBlocking: false,
    accountAgeLimits: false,
    individualBlocking: true
  },
  streaming: {
    authGated: true,
    playbackUrlMustComeFromApi: true,
    hardcodedUrlsForbidden: true,
    stopOnLogout: true
  }
} as const;
