import { Router } from 'express';
import { z } from 'zod';

export const settingsRouter = Router();

const algorithmSchema = z.object({
  rankingLogic: z.enum(['latest', 'engagement', 'hybrid', 'following_first']),
  prioritizeStories: z.boolean(),
  prioritizeBadges: z.boolean(),
  allowNsfw: z.boolean(),
  allowAds: z.boolean()
});

settingsRouter.post('/algorithm', (req, res) => {
  const value = algorithmSchema.parse(req.body);
  const sanitized = {
    ...value,
    allowNsfw: value.allowNsfw,
    safetyOverridesApplied: true
  };

  res.json({ saved: true, algorithm: sanitized });
});
