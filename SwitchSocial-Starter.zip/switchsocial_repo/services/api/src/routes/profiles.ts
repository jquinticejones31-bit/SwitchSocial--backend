import { Router } from 'express';
import { recommendedBadge } from '@switchsocial/shared/rules/badges';

export const profileRouter = Router();

profileRouter.get('/:handle', (req, res) => {
  const profile = {
    id: 'user_1',
    handle: req.params.handle,
    displayName: 'Demo User',
    type: 'regular',
    followers: 1240,
    friendsEnabled: true,
    verifiedEmail: true,
    lgbtqOptIn: false
  } as const;

  res.json({
    ...profile,
    badge: recommendedBadge(profile as any),
    pagesSupported: false,
    storiesNeverExpire: true
  });
});
