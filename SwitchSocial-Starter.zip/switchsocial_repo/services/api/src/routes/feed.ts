import { Router } from 'express';

export const feedRouter = Router();

feedRouter.get('/', (req, res) => {
  const tab = (req.query.tab as string) || 'linkups';
  res.json({
    tab,
    whyAmISeeingThis: 'Shown because you follow the author and your selected algorithm prioritizes recent posts.',
    items: [
      {
        id: 'post_1',
        author: '@switchsocial',
        text: 'Welcome to SwitchSocial.',
        labels: ['ai-none', 'manipulation-none'],
        storyPersistent: true
      }
    ]
  });
});
