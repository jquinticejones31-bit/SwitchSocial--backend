import { Router } from 'express';

export const streamingRouter = Router();

streamingRouter.get('/', (req, res) => {
  const auth = req.header('authorization');
  if (!auth?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'missing_bearer_token' });
  }

  res.json({
    playbackUrl: 'https://example-playback-url.invalid/stream.m3u8',
    apikey: process.env.PLAYBACK_API_KEY ?? 'replace-me',
    expiresInSeconds: 300
  });
});
