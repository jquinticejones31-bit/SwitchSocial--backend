import { Router } from 'express';

export const paymentsRouter = Router();

paymentsRouter.get('/config', (_req, res) => {
  res.json({
    webProcessor: 'stripe',
    iosDigitalGoods: 'apple_iap_required_where_applicable',
    androidDigitalGoods: 'google_play_billing_required_where_applicable',
    p2p: {
      provider: 'stripe_connect',
      kycRequired: true,
      amlRequired: true,
      fraudChecksRequired: true
    }
  });
});
