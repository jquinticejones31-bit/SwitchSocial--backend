import { Router } from 'express';
import { z } from 'zod';

export const authRouter = Router();

const signupSchema = z.object({
  email: z.string().email(),
  teenAccount: z.boolean().default(false),
  parentConsentToken: z.string().optional(),
  deviceTrust: z.enum(['personal', 'shared']).default('personal')
});

authRouter.post('/signup/options', (req, res) => {
  const body = signupSchema.parse(req.body);
  if (body.teenAccount && !body.parentConsentToken) {
    return res.status(400).json({
      error: 'parental_consent_required',
      message: 'Teen accounts require verified parental consent before passkey registration.'
    });
  }

  res.json({
    challenge: 'replace-with-webauthn-registration-challenge',
    rp: { id: process.env.PASSKEY_RP_ID, name: process.env.PASSKEY_RP_NAME },
    userVerification: 'required',
    saveCredentialAllowed: body.deviceTrust === 'personal'
  });
});

authRouter.post('/login/options', (_req, res) => {
  res.json({
    challenge: 'replace-with-webauthn-authentication-challenge',
    userVerification: 'required'
  });
});

authRouter.post('/logout', (_req, res) => {
  res.json({ loggedOut: true, invalidatePlayback: true, invalidateSessions: true });
});
