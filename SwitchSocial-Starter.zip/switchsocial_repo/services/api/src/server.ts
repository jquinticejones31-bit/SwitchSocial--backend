import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import { authRouter } from './routes/auth';
import { feedRouter } from './routes/feed';
import { profileRouter } from './routes/profiles';
import { settingsRouter } from './routes/settings';
import { streamingRouter } from './routes/streaming';
import { paymentsRouter } from './routes/payments';

const app = express();
app.use(cors({ origin: process.env.WEB_URL ?? '*' }));
app.use(helmet());
app.use(morgan('dev'));
app.use(express.json());

app.get('/health', (_req, res) => {
  res.json({ ok: true, service: 'switchsocial-api' });
});

app.use('/auth', authRouter);
app.use('/feed', feedRouter);
app.use('/profiles', profileRouter);
app.use('/settings', settingsRouter);
app.use('/playback', streamingRouter);
app.use('/payments', paymentsRouter);

app.use((err: Error, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error(err);
  res.status(500).json({ error: 'internal_server_error', message: err.message });
});

const port = Number(process.env.PORT ?? 4000);
app.listen(port, () => {
  console.log(`API listening on http://localhost:${port}`);
});
