# Service implementation notes

Recommended production services to add:
- passkey registration / assertion verification
- email verification provider
- parental consent provider
- moderation decisioning + appeal queues
- AI text/image/video labeling pipeline
- manipulation detection pipeline
- Stripe Connect accounts, payouts, and P2P risk controls
- storage + CDN + transcoding for media and stories
- relational database + cache + search index
