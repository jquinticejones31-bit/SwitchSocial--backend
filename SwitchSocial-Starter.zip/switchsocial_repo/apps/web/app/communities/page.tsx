export default function CommunitiesPage() {
  return (
    <div className="card">
      <h2>Talkyard Communities</h2>
      <p>Community rules, SFW / NSFW classification, moderators, voting, and nested comments.</p>
    </div>
  );
}
