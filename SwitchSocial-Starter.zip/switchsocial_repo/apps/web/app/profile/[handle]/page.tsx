export default async function ProfilePage({ params }: { params: Promise<{ handle: string }> }) {
  const { handle } = await params;
  return (
    <div className="card">
      <h2>@{handle}</h2>
      <span className="badge">Profile only</span>
      <p className="muted">No pages exist on SwitchSocial. Profiles support unlimited followers and optional friends.</p>
    </div>
  );
}
