export default function StoriesPage() {
  return (
    <div className="card">
      <h2>Stories Viewer</h2>
      <p>Stories support photo, video, and text. They remain until the user deletes them.</p>
      <p className="muted">AI-generated stories must show labels.</p>
    </div>
  );
}
