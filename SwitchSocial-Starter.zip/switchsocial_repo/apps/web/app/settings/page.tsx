export default function SettingsPage() {
  return (
    <div className="card">
      <h2>Settings</h2>
      <div className="grid2">
        <div>
          <h3>Global</h3>
          <p className="muted">Account, safety, privacy, passkeys, notifications, parental consent.</p>
        </div>
        <div>
          <h3>Per tab</h3>
          <p className="muted">Feed preferences, stories, NSFW preference, and ad visibility.</p>
        </div>
      </div>
    </div>
  );
}
