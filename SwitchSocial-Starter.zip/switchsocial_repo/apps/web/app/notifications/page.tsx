export default function NotificationsPage() {
  return <div className="card"><h2>Notifications</h2><p>Combined notification center for both product tabs.</p></div>;
}
