import './globals.css';
import Link from 'next/link';
import React from 'react';

export const metadata = {
  title: 'SwitchSocial',
  description: 'Unified social platform starter'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <div className="shell">
          <aside className="sidebar">
            <h1>SwitchSocial</h1>
            <p className="muted">One identity. Two social surfaces.</p>
            <nav className="nav">
              <Link href="/">Home</Link>
              <Link href="/login">Login / Signup</Link>
              <Link href="/profile/demo">Profile</Link>
              <Link href="/stories">Stories</Link>
              <Link href="/feed">Feed</Link>
              <Link href="/messages">Messages</Link>
              <Link href="/notifications">Notifications</Link>
              <Link href="/communities">Communities</Link>
              <Link href="/wallet">Wallet</Link>
              <Link href="/settings">Settings</Link>
            </nav>
          </aside>
          <main className="main">{children}</main>
          <aside className="rightbar">
            <div className="card">
              <h3>Product tabs</h3>
              <p>Linkups</p>
              <p>Talkyard</p>
            </div>
            <div className="card">
              <h3>Safety</h3>
              <p className="muted">AI labels, manipulation detection, teen protections, appeals, and policy overrides are built into the starter architecture.</p>
            </div>
          </aside>
        </div>
      </body>
    </html>
  );
}
