export default function MessagesPage() {
  return (
    <div className="card">
      <h2>Messaging Inbox</h2>
      <p>Anyone can message anyone. Users can block individuals. No global chat blocking.</p>
    </div>
  );
}
