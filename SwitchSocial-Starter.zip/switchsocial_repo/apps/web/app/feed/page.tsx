export default function FeedPage() {
  return (
    <div className="card">
      <h2>Feed</h2>
      <p>Two feed surfaces: Linkups and Talkyard. Users can select their own algorithm settings.</p>
      <p className="muted">Transparency module: Why am I seeing this?</p>
    </div>
  );
}
