export default function LoginPage() {
  return (
    <div className="card">
      <h2>Passkey login / signup</h2>
      <p className="muted">One verified email. No passwords. Teen signups require verified parental consent.</p>
      <label>Email<input className="input" type="email" placeholder="you@example.com" /></label>
      <label>Device type
        <select className="input" defaultValue="personal">
          <option value="personal">Personal device</option>
          <option value="shared">Shared / school / public device</option>
        </select>
      </label>
      <button className="button">Continue with passkey</button>
    </div>
  );
}
