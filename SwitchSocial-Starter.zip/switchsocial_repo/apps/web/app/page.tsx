export default function Page() {
  return (
    <>
      <div className="card">
        <h2>Authenticated homepage</h2>
        <p>Unified entry point for Linkups and Talkyard with streaming playback, feed previews, wallet access, and notifications.</p>
      </div>
      <div className="grid2">
        <div className="card">
          <h3>Streaming playback</h3>
          <p className="muted">Playback URL must be fetched from the API after auth. Do not hardcode stream URLs.</p>
          <button className="button">Fetch playback</button>
        </div>
        <div className="card">
          <h3>Algorithm builder</h3>
          <p className="muted">Users can choose feed logic, stories priority, badge priority, NSFW visibility, and ad visibility. Safety overrides still apply.</p>
        </div>
      </div>
    </>
  );
}
