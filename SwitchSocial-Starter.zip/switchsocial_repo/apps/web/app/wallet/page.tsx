export default function WalletPage() {
  return (
    <div className="card">
      <h2>Payments / Wallet</h2>
      <p>Subscriptions, ads, payouts, and P2P transfer flows with Stripe for web and app-store compliant billing for in-app digital purchases where required.</p>
    </div>
  );
}
