import React from 'react';
import { SafeAreaView, ScrollView, Text, View } from 'react-native';

const Card = ({ title, text }) => (
  <View style={{ backgroundColor: '#141b31', padding: 16, borderRadius: 16, marginBottom: 12 }}>
    <Text style={{ color: 'white', fontSize: 18, fontWeight: '700', marginBottom: 8 }}>{title}</Text>
    <Text style={{ color: '#c5d0ea' }}>{text}</Text>
  </View>
);

export default function App() {
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#0b1020' }}>
      <ScrollView contentContainerStyle={{ padding: 20 }}>
        <Text style={{ color: 'white', fontSize: 28, fontWeight: '800', marginBottom: 16 }}>SwitchSocial</Text>
        <Card title="Linkups + Talkyard" text="Two social surfaces under one account and one verified identity." />
        <Card title="Passkeys only" text="No-password authentication flow with shared-device protections and teen parental consent gating." />
        <Card title="Stories + AI labels" text="Stories never expire unless deleted, and synthetic content should be labeled." />
      </ScrollView>
    </SafeAreaView>
  );
}
