# SwitchSocial

SwitchSocial is a starter monorepo for a unified social platform with two product surfaces:
- **Linkups** — a friends/followers social feed
- **Talkyard** — a community discussion network

This repo is a **build-ready starter** with:
- Next.js web app
- Expo mobile app scaffold
- Node/Express API
- shared TypeScript package for product rules
- policy and legal starter docs
- placeholder flows for passkeys, streaming playback, payments, moderation, badge rules, stories, algorithms, and AI media labeling

## Monorepo layout

- `apps/web` — Next.js authenticated web UI
- `apps/mobile` — Expo React Native mobile scaffold
- `services/api` — Express API with routes and policy-aware service logic
- `packages/shared` — platform rules, badges, boosts, safety types
- `docs` — legal and compliance starter docs

## Core product assumptions

- One account, one verified email, one identity
- Passwordless authentication with passkeys only
- Teen onboarding requires parental consent verification
- Profiles only, no pages
- Stories do not expire unless the user deletes them
- Streaming uses API-returned playback URLs only
- AI-generated and heavily manipulated media must be labeled
- Platform safety overrides always take precedence over custom algorithms

## Quick start

### Requirements
- Node.js 20+
- npm 10+

### Install
```bash
npm install
```

### Run everything in development
```bash
npm run dev
```

### Individual apps
```bash
npm run dev:web
npm run dev:mobile
npm run dev:api
```

## Environment variables
Copy `.env.example` to `.env` in the repo root and to service/app-specific env files as needed.

## Notes
This starter intentionally includes policy-safe language, implementation placeholders, and data contracts. Before production use, you should complete:
- database + migrations
- real passkey verification
- Stripe / Apple / Google billing integrations
- parental consent vendor integration
- moderation ops tooling
- AI/media detection pipeline
- legal review by counsel
