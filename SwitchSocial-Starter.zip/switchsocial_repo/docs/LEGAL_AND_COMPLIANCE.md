# SwitchSocial Legal + Compliance Starter

## Product separation
- Linkups supplemental terms
- Talkyard supplemental terms
- platform-wide terms

## Safety posture
- child safety and anti-exploitation controls are mandatory
- user reporting, appeals, and enforcement records required
- high-reach misinformation may be labeled, limited, or removed

## Privacy posture
- minimal collection
- no sale of personal data
- lawful international transfer mechanisms required
- additional teen protections

## Regional compliance targets
- COPPA
- GDPR / UK GDPR
- EU DSA
- UK Online Safety Act
- PIPEDA
- AU Privacy Act

## Billing posture
- iOS digital goods must use Apple in-app purchase where required
- Android digital goods must use Google Play Billing where required
- web payments and payouts may use Stripe
- P2P payments require KYC / AML / fraud controls

## Identity and verification
- email verification required
- passkeys only
- badge application is free
- badge evidence and audit logging required

## AI / media integrity
- synthetic or materially manipulated media may require labels
- deceptive harmful manipulation may be removed
- appeals path should exist for false positives
