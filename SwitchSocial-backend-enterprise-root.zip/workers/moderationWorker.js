function moderationWorker() {
  return 'moderation worker scaffold';
}

module.exports = { moderationWorker };
