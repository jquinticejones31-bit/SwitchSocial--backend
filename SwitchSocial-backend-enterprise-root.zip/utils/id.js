const { v4: uuidv4 } = require('uuid');
function makeId(prefix) { return `${prefix}_${uuidv4()}`; }
module.exports = { makeId };
