const fs = require('fs');
const path = require('path');
console.log('Migration runner scaffold');
console.log(fs.readdirSync(path.join(__dirname)).filter((f) => f.endsWith('.sql')));
