console.log('Seed runner scaffold');
console.log('Add demo users, posts, communities, stories, and algorithms here.');
