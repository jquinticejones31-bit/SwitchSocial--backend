const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
require('dotenv').config();

const authRoutes = require('./routes/authRoutes');
const feedRoutes = require('./routes/feedRoutes');
const talkyardRoutes = require('./routes/talkyardRoutes');
const storyRoutes = require('./routes/storyRoutes');
const paymentRoutes = require('./routes/paymentRoutes');
const aiRoutes = require('./routes/aiRoutes');
const moderationRoutes = require('./routes/moderationRoutes');
const algorithmRoutes = require('./routes/algorithmRoutes');
const mediaRoutes = require('./routes/mediaRoutes');
const playbackRoutes = require('./routes/playbackRoutes');
const profileRoutes = require('./routes/profileRoutes');
const reportRoutes = require('./routes/reportRoutes');
const walletRoutes = require('./routes/walletRoutes');
const healthRoutes = require('./routes/healthRoutes');
const errorHandler = require('./middleware/errorHandler');

const app = express();

app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_URL || '*' }));
app.use(express.json({ limit: '25mb' }));
app.use(morgan('dev'));

app.use('/health', healthRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/profiles', profileRoutes);
app.use('/api/feed', feedRoutes);
app.use('/api/talkyard', talkyardRoutes);
app.use('/api/stories', storyRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/wallet', walletRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/moderation', moderationRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/algorithms', algorithmRoutes);
app.use('/api/media', mediaRoutes);
app.use('/api/playback', playbackRoutes);

app.get('/', (req, res) => {
  res.json({
    ok: true,
    service: 'SwitchSocial Backend',
    rootStructure: [
      'Dockerfile',
      'package.json',
      'server.js',
      'other backend files...'
    ],
    features: [
      'passkey authentication',
      'Linkups feed engine',
      'Talkyard discussion engine',
      'permanent stories system',
      'Stripe + P2P payments',
      'AI / Photoshop detection service',
      'PostgreSQL schema + migrations',
      'moderation + reporting',
      'user-created algorithm engine',
      'media storage service',
      'streaming playback service'
    ]
  });
});

app.use(errorHandler);

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`SwitchSocial backend running on port ${PORT}`);
});
