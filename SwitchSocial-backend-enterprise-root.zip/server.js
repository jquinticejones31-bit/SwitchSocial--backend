const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
require('dotenv').config();

const healthRoutes = require('./routes/healthRoutes');
const authRoutes = require('./routes/authRoutes');
const profileRoutes = require('./routes/profileRoutes');
const feedRoutes = require('./routes/feedRoutes');
const talkyardRoutes = require('./routes/talkyardRoutes');
const storyRoutes = require('./routes/storyRoutes');
const paymentRoutes = require('./routes/paymentRoutes');
const walletRoutes = require('./routes/walletRoutes');
const aiRoutes = require('./routes/aiRoutes');
const moderationRoutes = require('./routes/moderationRoutes');
const reportRoutes = require('./routes/reportRoutes');
const algorithmRoutes = require('./routes/algorithmRoutes');
const mediaRoutes = require('./routes/mediaRoutes');
const notificationRoutes = require('./routes/notificationRoutes');
const messageRoutes = require('./routes/messageRoutes');
const errorHandler = require('./middleware/errorHandler');

const app = express();

app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_URL || '*' }));
app.use(express.json({ limit: '25mb' }));
app.use(morgan('dev'));

app.use('/health', healthRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/profiles', profileRoutes);
app.use('/api/feed', feedRoutes);
app.use('/api/talkyard', talkyardRoutes);
app.use('/api/stories', storyRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/wallet', walletRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/moderation', moderationRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/algorithms', algorithmRoutes);
app.use('/api/media', mediaRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/messages', messageRoutes);

app.get('/', (req, res) => {
  res.json({
    ok: true,
    service: 'SwitchSocial Backend',
    rootFiles: ['Dockerfile', 'package.json', 'server.js'],
    features: [
      'passkey authentication',
      'Linkups feed engine',
      'Talkyard discussion engine',
      'permanent stories system',
      'Stripe + P2P payments',
      'AI / Photoshop detection service',
      'PostgreSQL schema + migrations',
      'moderation + reporting',
      'user-created algorithm engine',
      'media storage service'
    ]
  });
});

app.use(errorHandler);

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
  console.log(`SwitchSocial backend running on port ${PORT}`);
});
