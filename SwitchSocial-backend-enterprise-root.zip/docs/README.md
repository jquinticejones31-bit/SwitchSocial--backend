SwitchSocial backend scaffold without streaming/playback.
Root folder preserved:
- Dockerfile
- package.json
- server.js
- other backend files
