SwitchSocial backend enterprise-style scaffold.

Root folder preserved:
- Dockerfile
- package.json
- server.js
- other backend files
