const { ok } = require('../utils/response');
const { listNotifications } = require('../services/notificationService');
function index(req, res) { return ok(res, listNotifications()); }
module.exports = { index };
