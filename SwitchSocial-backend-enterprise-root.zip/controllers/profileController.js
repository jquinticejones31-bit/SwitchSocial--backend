const { ok } = require('../utils/response');
const { getProfile } = require('../services/profileService');

function show(req, res) {
  return ok(res, getProfile(req.params.id));
}

module.exports = { show };
