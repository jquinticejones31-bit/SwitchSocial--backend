const { ok } = require('../utils/response');
const { getCommunities } = require('../services/talkyardService');

function communities(req, res) {
  return ok(res, getCommunities());
}

module.exports = { communities };
