const { ok } = require('../utils/response');
const { getLinkupsFeed } = require('../services/feedService');
function home(req, res) { return ok(res, getLinkupsFeed()); }
module.exports = { home };
