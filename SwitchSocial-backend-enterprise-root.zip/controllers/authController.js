const { ok, fail } = require('../utils/response');
const { beginRegistration, beginAuthentication } = require('../services/passkeyService');
function registerPasskey(req, res) {
  if (!req.body.email) return fail(res, 'Email is required');
  return ok(res, beginRegistration(req.body.email));
}
function loginPasskey(req, res) {
  if (!req.body.email) return fail(res, 'Email is required');
  return ok(res, beginAuthentication(req.body.email));
}
module.exports = { registerPasskey, loginPasskey };
