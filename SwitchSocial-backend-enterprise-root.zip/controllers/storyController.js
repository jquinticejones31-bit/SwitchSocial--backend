const { ok } = require('../utils/response');
const { getStories } = require('../services/storyService');
function index(req, res) { return ok(res, getStories()); }
module.exports = { index };
