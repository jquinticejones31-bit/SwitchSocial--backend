const { ok } = require('../utils/response');
const { inbox } = require('../services/messageService');
function list(req, res) { return ok(res, inbox()); }
module.exports = { list };
