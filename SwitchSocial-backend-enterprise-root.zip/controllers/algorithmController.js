const { ok } = require('../utils/response');
const { getBuilder } = require('../services/algorithmService');

function builder(req, res) {
  return ok(res, getBuilder());
}

module.exports = { builder };
