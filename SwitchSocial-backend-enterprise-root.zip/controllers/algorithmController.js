const { ok } = require('../utils/response');
const { getBuilder, saveUserAlgorithm } = require('../services/algorithmService');
function builder(req, res) { return ok(res, getBuilder()); }
function save(req, res) { return ok(res, saveUserAlgorithm(req.body || {})); }
module.exports = { builder, save };
