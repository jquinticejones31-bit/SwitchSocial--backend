const { ok } = require('../utils/response');
const { scanContent } = require('../services/aiDetectionService');
function scan(req, res) { return ok(res, scanContent(req.body)); }
module.exports = { scan };
