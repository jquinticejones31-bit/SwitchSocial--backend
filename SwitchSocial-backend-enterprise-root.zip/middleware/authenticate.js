module.exports = function authenticate(req, res, next) {
  req.user = {
    id: 'user_demo_1',
    email: 'demo@switchsocial.app',
    verifiedEmail: true,
    passkeyAuthenticated: true
  };
  next();
};
