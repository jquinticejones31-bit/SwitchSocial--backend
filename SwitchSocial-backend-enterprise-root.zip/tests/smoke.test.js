console.log('Smoke test scaffold: project boots with root server.js and package.json');
