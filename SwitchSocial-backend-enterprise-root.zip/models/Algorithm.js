class Algorithm { constructor(data = {}) { Object.assign(this, data); } } module.exports = Algorithm;
