class Message {
  constructor(data = {}) {
    Object.assign(this, data);
  }
}
module.exports = Message;
