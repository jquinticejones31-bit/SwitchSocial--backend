class Comment {
  constructor(data = {}) {
    Object.assign(this, data);
  }
}
module.exports = Comment;
