class Community { constructor(data = {}) { Object.assign(this, data); } } module.exports = Community;
