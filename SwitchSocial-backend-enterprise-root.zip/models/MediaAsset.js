class MediaAsset {
  constructor(data = {}) {
    Object.assign(this, data);
  }
}
module.exports = MediaAsset;
