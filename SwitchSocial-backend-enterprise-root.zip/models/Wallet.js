class Wallet {
  constructor(data = {}) {
    Object.assign(this, data);
  }
}
module.exports = Wallet;
