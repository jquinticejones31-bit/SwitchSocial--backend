class PasskeyCredential {
  constructor(data = {}) {
    Object.assign(this, data);
  }
}
module.exports = PasskeyCredential;
