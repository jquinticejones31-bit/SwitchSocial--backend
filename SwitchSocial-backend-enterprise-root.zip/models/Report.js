class Report {
  constructor(data = {}) {
    Object.assign(this, data);
  }
}
module.exports = Report;
