class Notification {
  constructor(data = {}) {
    Object.assign(this, data);
  }
}
module.exports = Notification;
