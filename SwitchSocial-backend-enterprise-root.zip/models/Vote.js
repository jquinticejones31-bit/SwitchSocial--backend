class Vote {
  constructor(data = {}) {
    Object.assign(this, data);
  }
}
module.exports = Vote;
