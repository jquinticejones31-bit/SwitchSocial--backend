function getWallet(userId) {
  return {
    userId,
    provider: 'Stripe',
    p2pEnabled: true,
    subscriptionsEnabled: true,
    creatorPayoutsEnabled: true,
    balance: 0,
    currency: 'USD'
  };
}
function createP2PTransfer(body) {
  return {
    type: 'p2p',
    recipientUserId: body.recipientUserId,
    amount: body.amount,
    currency: body.currency || 'USD',
    status: 'pending'
  };
}
module.exports = { getWallet, createP2PTransfer };
