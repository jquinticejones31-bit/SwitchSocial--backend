function compileAlgorithm(config = {}) {
  return {
    compiled: true,
    config,
    safetyOverridesApply: true,
    transparency: 'Why am I seeing this?'
  };
}
module.exports = { compileAlgorithm };
