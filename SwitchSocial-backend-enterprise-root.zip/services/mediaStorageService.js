function uploadMedia(body = {}) {
  return {
    provider: process.env.MEDIA_STORAGE_PROVIDER || 'gcs',
    bucket: process.env.MEDIA_STORAGE_BUCKET || 'switchsocial-media',
    filename: body.filename || 'placeholder.file',
    status: 'stored_placeholder'
  };
}
module.exports = { uploadMedia };
