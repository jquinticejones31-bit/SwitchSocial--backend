function rankFeed(items = []) {
  return [...items].sort((a, b) => (b.score || 0) - (a.score || 0));
}
module.exports = { rankFeed };
