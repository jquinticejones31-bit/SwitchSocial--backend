function getCommunities() {
  return {
    network: 'Talkyard',
    communities: [
      { id: 'community_1', name: 'General', nsfw: false },
      { id: 'community_2', name: 'Creators', nsfw: true }
    ],
    features: ['nested_comments', 'upvotes', 'downvotes', 'mods_and_rules']
  };
}

module.exports = { getCommunities };
