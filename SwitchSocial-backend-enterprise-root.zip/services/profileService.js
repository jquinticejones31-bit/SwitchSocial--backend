function getProfile(id) {
  return {
    id,
    username: 'switchsocial_user',
    profileType: 'regular',
    followers: 120,
    friendsEnabled: true
  };
}

module.exports = { getProfile };
