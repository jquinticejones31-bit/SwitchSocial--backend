function createReport(body = {}) {
  return {
    contentId: body.contentId || 'unknown',
    reason: body.reason || 'unspecified',
    status: 'open',
    appealsSupported: true
  };
}

module.exports = { createReport };
