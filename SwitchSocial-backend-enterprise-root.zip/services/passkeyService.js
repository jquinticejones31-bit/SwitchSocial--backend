const { makeId } = require('../utils/id');

function beginRegistration(email) {
  return {
    registrationId: makeId('reg'),
    email,
    method: 'passkey_only',
    requiresEmailVerification: true,
    challenge: 'replace-with-real-webauthn-registration-challenge'
  };
}

function beginAuthentication(email) {
  return {
    authenticationId: makeId('auth'),
    email,
    method: 'passkey_only',
    challenge: 'replace-with-real-webauthn-authentication-challenge'
  };
}

module.exports = { beginRegistration, beginAuthentication };
