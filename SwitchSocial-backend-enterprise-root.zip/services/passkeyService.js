const { makeId } = require('../utils/id');
function beginRegistration(email) {
  return {
    registrationId: makeId('reg'),
    email,
    challenge: 'replace-with-real-webauthn-registration-challenge',
    method: 'passkey_only',
    requiresEmailVerification: true
  };
}
function beginAuthentication(email) {
  return {
    authenticationId: makeId('auth'),
    email,
    challenge: 'replace-with-real-webauthn-authentication-challenge',
    method: 'passkey_only'
  };
}
module.exports = { beginRegistration, beginAuthentication };
