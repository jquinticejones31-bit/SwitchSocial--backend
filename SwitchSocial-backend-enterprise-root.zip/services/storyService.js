function getStories() {
  return {
    permanentUntilDeleted: true,
    items: [
      { id: 'story_1', type: 'image', aiLabeled: false },
      { id: 'story_2', type: 'video', aiLabeled: true }
    ]
  };
}
module.exports = { getStories };
