const { compileAlgorithm } = require('./algorithmCompilerService');
function getBuilder() {
  return {
    controls: ['ranking_logic', 'stories_priority', 'badges', 'nsfw', 'ads'],
    defaultAlgorithmAlwaysAvailable: true
  };
}
function saveUserAlgorithm(config = {}) {
  return compileAlgorithm(config);
}
module.exports = { getBuilder, saveUserAlgorithm };
