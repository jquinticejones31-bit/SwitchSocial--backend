function getBuilder() {
  return {
    controls: ['ranking_logic', 'stories_priority', 'badges', 'nsfw', 'ads'],
    defaultAlgorithmAlwaysAvailable: true,
    safetyOverridesApply: true,
    transparency: 'Why am I seeing this?'
  };
}

module.exports = { getBuilder };
