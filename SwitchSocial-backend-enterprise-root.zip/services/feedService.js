const { rankFeed } = require('./feedRankingService');
function getLinkupsFeed() {
  const items = [
    { id: 'post_1', type: 'post', text: 'Welcome to Linkups', score: 10 },
    { id: 'post_2', type: 'image', text: 'Image post example', score: 8 },
    { id: 'post_3', type: 'video', text: 'Video post example', score: 12 }
  ];
  return { network: 'Linkups', items: rankFeed(items) };
}
module.exports = { getLinkupsFeed };
