function getLinkupsFeed() {
  return {
    network: 'Linkups',
    engine: 'ranking_engine_v1',
    items: [
      { id: 'post_1', type: 'post', text: 'Welcome to Linkups' },
      { id: 'post_2', type: 'image', text: 'Image post example' },
      { id: 'post_3', type: 'video', text: 'Video post example' }
    ]
  };
}

module.exports = { getLinkupsFeed };
