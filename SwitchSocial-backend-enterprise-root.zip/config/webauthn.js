module.exports = {
  rpID: process.env.WEBAUTHN_RP_ID || 'localhost',
  rpName: process.env.WEBAUTHN_RP_NAME || 'SwitchSocial',
  origin: process.env.WEBAUTHN_ORIGIN || 'http://localhost:3000'
};
