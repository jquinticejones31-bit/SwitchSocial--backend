module.exports = function handleStripeWebhook(event) {
  return { received: true, type: event?.type || 'unknown' };
};
