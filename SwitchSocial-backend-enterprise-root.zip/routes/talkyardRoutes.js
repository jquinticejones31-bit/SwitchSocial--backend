const router = require('express').Router();
const controller = require('../controllers/talkyardController');
const authenticate = require('../middleware/authenticate');
router.get('/communities', authenticate, controller.communities);
module.exports = router;
