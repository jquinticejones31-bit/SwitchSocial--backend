const router = require('express').Router();
const controller = require('../controllers/aiController');
const authenticate = require('../middleware/authenticate');
router.post('/scan', authenticate, controller.scan);
module.exports = router;
