const router = require('express').Router();
const controller = require('../controllers/mediaController');
const authenticate = require('../middleware/authenticate');
router.post('/upload', authenticate, controller.upload);
module.exports = router;
