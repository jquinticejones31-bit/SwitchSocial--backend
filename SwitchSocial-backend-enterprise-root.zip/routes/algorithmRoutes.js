const router = require('express').Router();
const controller = require('../controllers/algorithmController');
const authenticate = require('../middleware/authenticate');
router.get('/builder', authenticate, controller.builder);
router.post('/save', authenticate, controller.save);
module.exports = router;
