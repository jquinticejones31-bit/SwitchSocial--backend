const router = require('express').Router();
const controller = require('../controllers/paymentController');
const authenticate = require('../middleware/authenticate');
router.get('/', authenticate, controller.wallet);
module.exports = router;
