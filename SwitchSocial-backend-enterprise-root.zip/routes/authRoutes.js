const router = require('express').Router();
const controller = require('../controllers/authController');
router.post('/passkey/register', controller.registerPasskey);
router.post('/passkey/login', controller.loginPasskey);
module.exports = router;
