const router = require('express').Router();
const controller = require('../controllers/storyController');
const authenticate = require('../middleware/authenticate');
router.get('/', authenticate, controller.index);
module.exports = router;
